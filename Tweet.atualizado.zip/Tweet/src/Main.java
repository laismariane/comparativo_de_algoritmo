import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.JFileChooser;

public class Main {

    public static void main(String[] args) {
        // Selecionar o arquivo tweets.csv
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecione o arquivo tweets.csv");
        int userSelection = fileChooser.showOpenDialog(null);
        if (userSelection != JFileChooser.APPROVE_OPTION) {
            System.out.println("Nenhum arquivo selecionado. Encerrando o programa.");
            return;
        }
        File file = fileChooser.getSelectedFile();
        String filePath = file.getAbsolutePath();

        // Transformações
        try {
            // Transformação 1: Formatação das datas
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            BufferedWriter writer = new BufferedWriter(new FileWriter("D:/tweets_formated_data.csv"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length <= 2) {
                    System.err.println("Erro: Linha inválida, pulando para a próxima linha.");
                    continue;
                }
                String dateString = parts[2]; // Assuming date is at index 2
                String text = parts[5]; // Assuming text is at index 5
                SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
                Date date;
                try {
                    date = inputFormat.parse(dateString);
                } catch (ParseException e) {
                    System.err.println("Erro ao analisar a data na linha: " + line);
                    continue;
                }
                SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
                String formattedDate = outputFormat.format(date);
                writer.write(formattedDate + "," + text + "\n");
            }
            reader.close();
            writer.close();
            System.out.println("Transformação 1 concluída. Arquivo 'tweets_formated_data.csv' gerado com sucesso.");

            // Transformação 2: Adição das colunas "mentioned_person" e
            // "mentioned_person_count"
            reader = new BufferedReader(new FileReader("D:/tweets_formated_data.csv"));
            writer = new BufferedWriter(new FileWriter("D:/tweets_mentioned_persons.csv"));
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String text = parts[1]; // Assuming text is at index 1
                Map<String, Integer> mentionedPersonsMap = new HashMap<>();
                String[] words = text.split("\\s+");
                for (String word : words) {
                    if (word.startsWith("@")) {
                        String mentionedPerson = word.substring(1);
                        mentionedPersonsMap.put(mentionedPerson,
                                mentionedPersonsMap.getOrDefault(mentionedPerson, 0) + 1);
                    }
                }
                String mentionedPersons = String.join("/", mentionedPersonsMap.keySet());
                int mentionedPersonCount = mentionedPersonsMap.size();
                writer.write(line + "," + (mentionedPersons.isEmpty() ? "null" : mentionedPersons) + ","
                        + mentionedPersonCount + "\n");
            }
            reader.close();
            writer.close();
            System.out.println("Transformação 2 concluída. Arquivo 'tweets_mentioned_persons.csv' gerado com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Ordenações
        try {
            // Ordenação 1: Ordenar o arquivo pela data dos tweets em ordem crescente
            ordenarPorData("D:/tweets_mentioned_persons.csv");

            // Ordenação 2: Ordenar o arquivo pelo número de pessoas mencionadas no tweet em
            // ordem decrescente
            ordenarPorMencoes("D:/tweets_mentioned_persons.csv");

            // Ordenação 3: Ordenar o arquivo em ordem alfabética pelo nome dos usuários
            ordenarPorUsuarios("D:/tweets_mentioned_persons.csv");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Todas as operações foram concluídas.");
    }

    // Ordenar o arquivo pela data dos tweets em ordem crescente
    private static void ordenarPorData(String filePath) throws IOException {
        String[] algoritmos = { "TreeMap" };
        String caso = "medioCaso";

        for (String algoritmo : algoritmos) {
            String outputFileName = "tweets_mentioned_persons_date_" + algoritmo + "_" + caso + ".csv";
            System.out.println("Ordenando por data com " + algoritmo + " (" + caso + ")...");
            List<String> lines = lerArquivo(filePath);
            // Usando TreeMap para ordenar as linhas por data
            TreeMap<Date, List<String>> sortedMap = new TreeMap<>();
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            for (String line : lines) {
                String[] parts = line.split(",");
                try {
                    Date date = format.parse(parts[0]);
                    sortedMap.putIfAbsent(date, new ArrayList<>());
                    sortedMap.get(date).add(line);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
            lines = new ArrayList<>();
            for (List<String> list : sortedMap.values()) {
                lines.addAll(list);
            }
            gerarArquivoOrdenado(lines, outputFileName);
        }
    }

    // Ordenar o arquivo pelo número de pessoas mencionadas no tweet em ordem
    // decrescente
    private static void ordenarPorMencoes(String filePath) throws IOException {
        String[] algoritmos = { "HashMap" };
        String caso = "medioCaso";

        for (String algoritmo : algoritmos) {
            String outputFileName = "tweets_mentioned_persons_count_" + algoritmo + "_" + caso + ".csv";
            System.out.println("Ordenando por menções com " + algoritmo + " (" + caso + ")...");
            List<String> lines = lerArquivo(filePath);
            // Implementar a ordenação usando o algoritmo especificado
            if (algoritmo.equals("HashMap")) {
                ordenarPorMencoesHashMap(lines);
            }
            gerarArquivoOrdenado(lines, outputFileName);
        }
    }

    // Implementação da ordenação por número de menções usando HashMap
    private static void ordenarPorMencoesHashMap(List<String> lines) {
        Map<String, Integer> mencoesMap = new HashMap<>();

        // Contar menções de cada usuário
        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length >= 8) { // Assumindo que a menção está na coluna 8 (0-indexado)
                String mentionedPersons = parts[8];
                String[] mentionedPersonsArray = mentionedPersons.split("/");
                for (String mentionedPerson : mentionedPersonsArray) {
                    mencoesMap.put(mentionedPerson, mencoesMap.getOrDefault(mentionedPerson, 0) + 1);
                }
            }
        }

        // Ordenar as linhas com base no número de menções em ordem decrescente
        lines.sort((line1, line2) -> {
            int count1 = 0;
            int count2 = 0;

            String[] parts1 = line1.split(",");
            String[] parts2 = line2.split(",");

            if (parts1.length >= 8) {
                String mentionedPersons1 = parts1[8];
                String[] mentionedPersonsArray1 = mentionedPersons1.split("/");
                count1 = Arrays.stream(mentionedPersonsArray1).mapToInt(mencoesMap::get).sum();
            }

            if (parts2.length >= 8) {
                String mentionedPersons2 = parts2[8];
                String[] mentionedPersonsArray2 = mentionedPersons2.split("/");
                count2 = Arrays.stream(mentionedPersonsArray2).mapToInt(mencoesMap::get).sum();
            }

            return Integer.compare(count2, count1); // Ordem decrescente
        });
    }

    // Ordenar o arquivo em ordem alfabética pelo nome dos usuários
    private static void ordenarPorUsuarios(String filePath) throws IOException {
        String[] algoritmos = { "ArrayList" };
        String caso = "medioCaso";

        for (String algoritmo : algoritmos) {
            String outputFileName = "tweets_mentioned_persons_user_" + algoritmo + "_" + caso + ".csv";
            System.out.println("Ordenando por usuários com " + algoritmo + " (" + caso + ")...");
            List<String> lines = lerArquivo(filePath);
            // Implementar a ordenação usando o algoritmo especificado
            if (algoritmo.equals("ArrayList")) {
                ordenarPorUsuariosArrayList(lines);
            }
            gerarArquivoOrdenado(lines, outputFileName);
        }
    }

    // Implementação da ordenação por usuários usando ArrayList
    private static void ordenarPorUsuariosArrayList(List<String> lines) {
        lines.sort((line1, line2) -> {
            String[] parts1 = line1.split(",");
            String[] parts2 = line2.split(",");
            return parts1[1].compareTo(parts2[1]); // Comparar pelo nome de usuário (assumindo que o nome está na coluna
                                                   // 1)
        });
    }

    // Função auxiliar para ler o arquivo e retornar as linhas como uma lista
    private static List<String> lerArquivo(String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            lines.add(line);
        }
        reader.close();
        return lines;
    }

    // Função auxiliar para gerar um arquivo com as linhas ordenadas
    private static void gerarArquivoOrdenado(List<String> lines, String outputFileName) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("D:/" + outputFileName));
        for (String line : lines) {
            writer.write(line + "\n");
        }
        writer.close();
        System.out.println("Arquivo '" + outputFileName + "' gerado com sucesso.");
    }
}
